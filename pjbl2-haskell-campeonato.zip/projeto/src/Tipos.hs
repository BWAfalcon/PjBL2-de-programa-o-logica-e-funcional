module Tipos
  ( Time
  , Resultado (..)
  , Partida (..)
  , Linha (..)
  , participou
  , resultadoPara
  , times
  ) where

import Data.List (nub, sort)

-- | Sinonimo de tipo para o nome de uma equipe.
type Time = String

-- | Possiveis resultados de uma partida sob a otica de um time.
data Resultado
  = Vitoria
  | Empate
  | Derrota
  deriving (Show, Eq)

-- | Registro que representa uma partida disputada no campeonato.
data Partida = Partida
  { rodada        :: Int
  , mandante      :: Time
  , golsMandante  :: Int
  , golsVisitante :: Int
  , visitante     :: Time
  } deriving (Show, Eq)

-- | Registro que representa a linha consolidada de um time na tabela.
data Linha = Linha
  { time       :: Time
  , jogos      :: Int
  , vitorias   :: Int
  , empates    :: Int
  , derrotas   :: Int
  , golsPro    :: Int
  , golsContra :: Int
  } deriving (Show, Eq)

-- | Verifica se o time informado participou da partida (como mandante ou visitante).
participou :: Time -> Partida -> Bool
participou t p = t == mandante p || t == visitante p

-- | Determina o resultado da partida sob o ponto de vista do time informado.
-- Retorna Nothing caso o time nao tenha disputado a partida.
resultadoPara :: Time -> Partida -> Maybe Resultado
resultadoPara t p
  | t == mandante p  = Just (compararPlacar (golsMandante p) (golsVisitante p))
  | t == visitante p = Just (compararPlacar (golsVisitante p) (golsMandante p))
  | otherwise        = Nothing
  where
    compararPlacar :: Int -> Int -> Resultado
    compararPlacar gp gc
      | gp > gc   = Vitoria
      | gp == gc  = Empate
      | otherwise = Derrota

-- | Lista todos os times participantes do campeonato, sem duplicatas e em ordem alfabetica.
times :: [Partida] -> [Time]
times = sort . nub . concatMap (\p -> [mandante p, visitante p])
