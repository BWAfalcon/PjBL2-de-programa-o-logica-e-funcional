module Main (main) where

import Classificacao
  ( aproveitamento
  , ateRodada
  , classificacao
  , maiorGoleada
  , mediaGols
  )
import Dados
  ( dadosCampeonato
  , dadosCampeonatoComErros
  , dadosCampeonatoVazio
  )
import Leitura
  ( formatarErro
  , lerCampeonato
  , tabelaFormatada
  , todosOsErros
  )
import Tipos (Linha (..), Partida (..), times)

-- | Formata uma partida para exibicao resumida nas estatisticas.
formatarPartida :: Partida -> String
formatarPartida p =
  "Rodada " ++ show (rodada p) ++ ": "
    ++ mandante p ++ " " ++ show (golsMandante p)
    ++ " x " ++ show (golsVisitante p) ++ " " ++ visitante p

-- | Exibe as estatisticas gerais da Camada 2.
exibirEstatisticas :: [Partida] -> [Linha] -> IO ()
exibirEstatisticas partidas tabela = do
  putStrLn "=== ESTATISTICAS DO CAMPEONATO (CAMADA 2) ==="
  case maiorGoleada partidas of
    Nothing -> putStrLn "Maior goleada: nenhuma partida disputada."
    Just p  -> putStrLn ("Maior goleada: " ++ formatarPartida p)
  case mediaGols partidas of
    Nothing -> putStrLn "Media de gols por partida: N/A"
    Just m  -> putStrLn ("Media de gols por partida: " ++ show m)
  case tabela of
    []        -> putStrLn "Lider: nenhum time classificado."
    (lider:_) ->
      putStrLn
        ( "Lider final: " ++ time lider
            ++ " (aproveitamento: " ++ show (aproveitamento lider) ++ "%)"
        )
  putStrLn ""

-- | Ponto de entrada principal: demonstra sequencialmente as tres camadas.
main :: IO ()
main = do
  putStrLn "============================================================"
  putStrLn "   PjBL2 - TABELA DE CLASSIFICACAO DE CAMPEONATO (HASKELL)  "
  putStrLn "============================================================"
  putStrLn ""

  case lerCampeonato dadosCampeonato of
    Left err -> putStrLn ("Erro inesperado nos dados validos: " ++ formatarErro err)
    Right partidas -> do
      let tabelaFinal = classificacao partidas
          tabelaR3    = classificacao (ateRodada 3 partidas)

      putStrLn "=== CAMADA 1: TIMES PARTICIPANTES ==="
      putStrLn ("Times (" ++ show (length (times partidas)) ++ "): " ++ show (times partidas))
      putStrLn ""

      putStrLn "=== CAMADA 2 & 3: CLASSIFICACAO FINAL (APOS 5 RODADAS) ==="
      putStr (tabelaFormatada tabelaFinal)
      putStrLn ""

      putStrLn "=== CAMADA 2: CLASSIFICACAO INTERMEDIARIA (ATE A 3a RODADA) ==="
      putStr (tabelaFormatada tabelaR3)
      putStrLn ""

      exibirEstatisticas partidas tabelaFinal

  putStrLn "=== TRATAMENTO DE CAMPEONATO VAZIO ==="
  case lerCampeonato dadosCampeonatoVazio of
    Left err -> putStrLn ("Erro: " ++ formatarErro err)
    Right ps -> putStrLn (tabelaFormatada (classificacao ps))
  putStrLn ""

  putStrLn "=== CAMADA 3: VALIDACAO DE ENTRADA COM ERROS ==="
  putStrLn "1) Resultado de lerCampeonato (para no primeiro erro):"
  case lerCampeonato dadosCampeonatoComErros of
    Right _  -> putStrLn "Inesperado: entrada invalida foi aceita."
    Left err -> putStrLn ("   -> " ++ formatarErro err)
  putStrLn ""

  putStrLn "2) Relatorio completo via todosOsErros:"
  mapM_ (\e -> putStrLn ("   - " ++ formatarErro e)) (todosOsErros dadosCampeonatoComErros)
