module Leitura
  ( Erro (..)
  , separar
  , lerPartida
  , lerCampeonato
  , todosOsErros
  , tabelaFormatada
  , formatarErro
  ) where

import Data.Char (isSpace, toLower)
import Data.Either (lefts, rights)
import Data.List (dropWhileEnd, intercalate)
import Data.Maybe (listToMaybe)
import Text.Read (readMaybe)
import Classificacao (aproveitamento, pontosLinha, saldo)
import Tipos (Linha (..), Partida (..), Time)

-- | Representa todos os possiveis erros de validacao na entrada textual.
data Erro
  = CamposInvalidos Int String
  | TimeVazio Int
  | NumeroInvalido Int String String
  | RodadaInvalida Int Int
  | PlacarNegativo Int String Int
  | MesmoTime Int Time
  | TimeRepetidoNaRodada Int Int Time
  deriving (Show, Eq)

-- | Converte um valor de Erro em uma mensagem descritiva legivel.
formatarErro :: Erro -> String
formatarErro (CamposInvalidos linha conteudo) =
  "Linha " ++ show linha ++ ": formato invalido (esperados 5 campos separados por ';'), recebido: " ++ show conteudo
formatarErro (TimeVazio linha) =
  "Linha " ++ show linha ++ ": nome de time mandante ou visitante nao pode ser vazio."
formatarErro (NumeroInvalido linha campo valor) =
  "Linha " ++ show linha ++ ": valor numerico invalido no campo '" ++ campo ++ "': " ++ show valor
formatarErro (RodadaInvalida linha r) =
  "Linha " ++ show linha ++ ": numero de rodada invalido (" ++ show r ++ "); deve ser maior que zero."
formatarErro (PlacarNegativo linha campo valor) =
  "Linha " ++ show linha ++ ": placar negativo nao permitido em '" ++ campo ++ "' (" ++ show valor ++ ")."
formatarErro (MesmoTime linha nomeTime) =
  "Linha " ++ show linha ++ ": o time '" ++ nomeTime ++ "' nao pode jogar contra si mesmo."
formatarErro (TimeRepetidoNaRodada linha r nomeTime) =
  "Linha " ++ show linha ++ ": o time '" ++ nomeTime ++ "' aparece mais de uma vez na rodada " ++ show r ++ "."

-- | Quebra uma string em substrings delimitadas pelo caractere separador.
separar :: Char -> String -> [String]
separar sep s =
  let (antes, resto) = break (== sep) s
  in case resto of
       []     -> [antes]
       (_:xs) -> antes : separar sep xs

-- | Remove espacos em branco no inicio e no fim de uma string.
aparar :: String -> String
aparar = dropWhileEnd isSpace . dropWhile isSpace

-- | Normaliza o nome de um time para comparacoes de igualdade insensiveis a caixa.
normalizarTime :: Time -> Time
normalizarTime = map toLower

-- | Verifica uma condicao booleana dentro da monada Either Erro.
validar :: Bool -> Erro -> Either Erro ()
validar condicao erro
  | condicao  = Right ()
  | otherwise = Left erro

-- | Converte um campo textual para Int usando readMaybe, retornando Left NumeroInvalido em caso de falha.
lerInteiro :: Int -> String -> String -> Either Erro Int
lerInteiro numLinha nomeCampo texto =
  maybe (Left (NumeroInvalido numLinha nomeCampo texto)) Right (readMaybe texto)

-- | Faz o parsing e a validacao estrutural/semantica de uma unica linha de partida.
lerPartida :: Int -> String -> Either Erro Partida
lerPartida numLinha linha = do
  let campos = map aparar (separar ';' linha)
  (strRodada, timeMandante, strGolsM, strGolsV, timeVisitante) <- case campos of
    [r, m, gm, gv, v] -> Right (r, m, gm, gv, v)
    _                 -> Left (CamposInvalidos numLinha linha)
  validar (not (null timeMandante) && not (null timeVisitante)) (TimeVazio numLinha)
  numRodada <- lerInteiro numLinha "rodada" strRodada
  validar (numRodada > 0) (RodadaInvalida numLinha numRodada)
  golsM <- lerInteiro numLinha "golsMandante" strGolsM
  golsV <- lerInteiro numLinha "golsVisitante" strGolsV
  validar (golsM >= 0) (PlacarNegativo numLinha "golsMandante" golsM)
  validar (golsV >= 0) (PlacarNegativo numLinha "golsVisitante" golsV)
  validar (normalizarTime timeMandante /= normalizarTime timeVisitante) (MesmoTime numLinha timeMandante)
  Right Partida
    { rodada        = numRodada
    , mandante      = timeMandante
    , golsMandante  = golsM
    , golsVisitante = golsV
    , visitante     = timeVisitante
    }

-- | Indica se uma linha deve ser ignorada (vazia ou comentario iniciado por '#').
-- Utiliza (<$>) sobre Maybe para inspecionar o primeiro caractere nao-branco.
ehLinhaIgnorada :: String -> Bool
ehLinhaIgnorada linha =
  let limpa = dropWhile isSpace linha
  in null limpa || (Just True == ((== '#') <$> listToMaybe limpa))

-- | Associa cada linha relevante ao seu numero original (baseado em 1) no texto.
linhasRelevantes :: String -> [(Int, String)]
linhasRelevantes =
  filter (not . ehLinhaIgnorada . snd) . zip ([1 ..] :: [Int]) . lines

-- | Verifica um par (numero da linha, partida) acumulando times ja vistos na rodada.
verificarParPartida :: Either Erro [(Int, Time)] -> (Int, Partida) -> Either Erro [(Int, Time)]
verificarParPartida acc (numLinha, p) = do
  vistos <- acc
  let r     = rodada p
      m     = mandante p
      v     = visitante p
      mNorm = normalizarTime m
      vNorm = normalizarTime v
  validar (notElem (r, mNorm) vistos) (TimeRepetidoNaRodada numLinha r m)
  validar (notElem (r, vNorm) vistos) (TimeRepetidoNaRodada numLinha r v)
  Right ((r, mNorm) : (r, vNorm) : vistos)

-- | Valida que nenhum time joga mais de uma vez na mesma rodada.
validarRodadas :: [(Int, Partida)] -> Either Erro ()
validarRodadas entradas = do
  _ <- foldl verificarParPartida (Right []) entradas
  Right ()

-- | Le o texto completo do campeonato, interrompendo no primeiro erro encontrado.
lerCampeonato :: String -> Either Erro [Partida]
lerCampeonato texto = do
  let entradas = linhasRelevantes texto
  partidas <- traverse (uncurry lerPartida) entradas
  validarRodadas (zip (map fst entradas) partidas)
  Right partidas

-- | Acumula todos os erros de duplicidade de times na mesma rodada sem interromper no primeiro.
coletarDuplicadosRodada :: ([(Int, Time)], [Erro]) -> (Int, Partida) -> ([(Int, Time)], [Erro])
coletarDuplicadosRodada (vistos, errs) (numLinha, p) =
  let r     = rodada p
      m     = mandante p
      v     = visitante p
      mNorm = normalizarTime m
      vNorm = normalizarTime v
      errM  = [TimeRepetidoNaRodada numLinha r m | (r, mNorm) `elem` vistos]
      errV  = [TimeRepetidoNaRodada numLinha r v | (r, vNorm) `elem` vistos]
  in ((r, mNorm) : (r, vNorm) : vistos, errs ++ errM ++ errV)

-- | Coleta todos os erros presentes no texto (erros de linha e conflitos de rodada).
todosOsErros :: String -> [Erro]
todosOsErros texto =
  let entradas      = linhasRelevantes texto
      resultados    = map (\(n, l) -> (n, lerPartida n l)) entradas
      errosDeLinha  = lefts (map snd resultados)
      validas       = rights (map (\(n, res) -> fmap (\p -> (n, p)) res) resultados)
      errosDeRodada = snd (foldl coletarDuplicadosRodada ([], []) validas)
  in errosDeLinha ++ errosDeRodada

-- | Alinha texto a esquerda preenchendo com espacos ate atingir a largura desejada.
alinharEsq :: Int -> String -> String
alinharEsq largura s = s ++ replicate (max 0 (largura - length s)) ' '

-- | Alinha texto a direita preenchendo com espacos a esquerda ate atingir a largura desejada.
alinharDir :: Int -> String -> String
alinharDir largura s = replicate (max 0 (largura - length s)) ' ' ++ s

-- | Formata um Double com uma casa decimal sem dependencias externas.
formatarDecimal1 :: Double -> String
formatarDecimal1 x =
  let decimos :: Int
      decimos = round (x * 10.0)
      inteiro = decimos `div` 10
      frac    = abs (decimos `mod` 10)
  in show inteiro ++ "." ++ show frac ++ "%"

-- | Formata a tabela de classificacao completa para exibicao textual.
tabelaFormatada :: [Linha] -> String
tabelaFormatada [] = "Nenhuma partida registrada no campeonato."
tabelaFormatada linhasTabela =
  let larguraTime = maximum (12 : map (length . time) linhasTabela)
      cabecalho =
        intercalate " | "
          [ alinharDir 3 "Pos"
          , alinharEsq larguraTime "Time"
          , alinharDir 3 "Pts"
          , alinharDir 2 "J"
          , alinharDir 2 "V"
          , alinharDir 2 "E"
          , alinharDir 2 "D"
          , alinharDir 3 "GP"
          , alinharDir 3 "GC"
          , alinharDir 4 "SG"
          , alinharDir 6 "Aprov"
          ]
      separadorLinha = replicate (length cabecalho) '-'
      formatarLinha (pos, l) =
        intercalate " | "
          [ alinharDir 3 (show pos)
          , alinharEsq larguraTime (time l)
          , alinharDir 3 (show (pontosLinha l))
          , alinharDir 2 (show (jogos l))
          , alinharDir 2 (show (vitorias l))
          , alinharDir 2 (show (empates l))
          , alinharDir 2 (show (derrotas l))
          , alinharDir 3 (show (golsPro l))
          , alinharDir 3 (show (golsContra l))
          , alinharDir 4 (show (saldo l))
          , alinharDir 6 (formatarDecimal1 (aproveitamento l))
          ]
      corpo = map formatarLinha (zip ([1 ..] :: [Int]) linhasTabela)
  in unlines (cabecalho : separadorLinha : corpo)
