module Dados
  ( dadosCampeonato
  , dadosCampeonatoComErros
  , dadosCampeonatoVazio
  ) where

-- | Campeonato de teste valido com 6 times, 5 rodadas (turno unico completo),
-- empate em 0x0, goleada por 4 gols de diferenca e desempate por saldo de gols.
dadosCampeonato :: String
dadosCampeonato = unlines
  [ "# Campeonato Paranaense de Teste - Turno Unico"
  , "# Formato: rodada; mandante; gols mandante; gols visitante; visitante"
  , ""
  , "# Rodada 1"
  , "1; Coritiba; 2; 2; Athletico"
  , "1; Parana; 0; 0; Operario"
  , "1; Londrina; 3; 0; Maringa"
  , ""
  , "# Rodada 2"
  , "2; Athletico; 4; 0; Maringa"
  , "2; Operario; 1; 2; Londrina"
  , "2; Coritiba; 1; 0; Parana"
  , ""
  , "# Rodada 3"
  , "3; Parana; 2; 1; Athletico"
  , "3; Londrina; 0; 1; Coritiba"
  , "3; Maringa; 2; 2; Operario"
  , ""
  , "# Rodada 4"
  , "4; Athletico; 3; 1; Operario"
  , "4; Coritiba; 1; 2; Maringa"
  , "4; Parana; 1; 1; Londrina"
  , ""
  , "# Rodada 5"
  , "5; Londrina; 1; 2; Athletico"
  , "5; Maringa; 1; 3; Parana"
  , "5; Operario; 0; 2; Coritiba"
  ]

-- | Entrada de teste propositalmente malformada contendo multiplos erros distintos
-- para validar lerCampeonato (para no primeiro) e todosOsErros (relata todos).
dadosCampeonatoComErros :: String
dadosCampeonatoComErros = unlines
  [ "# Exemplo de arquivo com erros de digitacao"
  , "1; Coritiba; 2; 1; Athletico"
  , "1; Parana; dois; 0; Operario"
  , "1; Coritiba; 1; 0; Londrina"
  , "2; Maringa; -1; 2; Operario"
  , "2; Athletico; 3; 3; Athletico"
  , "3; Parana; 1; 0"
  ]

-- | Entrada contendo apenas comentarios e linhas em branco (campeonato sem partidas).
dadosCampeonatoVazio :: String
dadosCampeonatoVazio = unlines
  [ "# Campeonato ainda nao iniciado"
  , ""
  , "   # Nenhuma partida disputada ate o momento"
  ]
