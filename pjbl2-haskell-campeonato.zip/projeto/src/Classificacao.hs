module Classificacao
  ( pontos
  , linhaDoTime
  , pontosLinha
  , saldo
  , aproveitamento
  , classificacao
  , ateRodada
  , maiorGoleada
  , mediaGols
  ) where

import Data.List (maximumBy, sortBy)
import Data.Ord (Down (..), comparing)
import Tipos
  ( Linha (..)
  , Partida (..)
  , Resultado (..)
  , Time
  , participou
  , resultadoPara
  , times
  )

-- | Pontuacao atribuida a cada resultado de partida.
pontos :: Resultado -> Int
pontos Vitoria = 3
pontos Empate  = 1
pontos Derrota = 0

-- | Linha inicial zerada para acumulacao estatistica de um time.
linhaInicial :: Time -> Linha
linhaInicial t = Linha
  { time       = t
  , jogos      = 0
  , vitorias   = 0
  , empates    = 0
  , derrotas   = 0
  , golsPro    = 0
  , golsContra = 0
  }

-- | Atualiza o acumulador da linha de um time com os dados de uma partida.
atualizarLinha :: Time -> Linha -> Partida -> Linha
atualizarLinha t acc p =
  case resultadoPara t p of
    Nothing -> acc
    Just res ->
      let (gp, gc) =
            if t == mandante p
              then (golsMandante p, golsVisitante p)
              else (golsVisitante p, golsMandante p)
      in acc
           { jogos      = jogos acc + 1
           , vitorias   = vitorias acc + if res == Vitoria then 1 else 0
           , empates    = empates acc + if res == Empate then 1 else 0
           , derrotas   = derrotas acc + if res == Derrota then 1 else 0
           , golsPro    = golsPro acc + gp
           , golsContra = golsContra acc + gc
           }

-- | Constroi a linha completa de um time a partir da lista de partidas usando foldl.
linhaDoTime :: [Partida] -> Time -> Linha
linhaDoTime ps t =
  foldl (atualizarLinha t) (linhaInicial t) (filter (participou t) ps)

-- | Total de pontos conquistados por um time na tabela.
pontosLinha :: Linha -> Int
pontosLinha l = vitorias l * 3 + empates l

-- | Saldo de gols (gols pro menos gols contra).
saldo :: Linha -> Int
saldo l = golsPro l - golsContra l

-- | Percentual de aproveitamento dos pontos disputados (0.0 a 100.0).
-- Retorna 0.0 caso o time ainda nao tenha disputado partidas.
aproveitamento :: Linha -> Double
aproveitamento l
  | jogos l == 0 = 0.0
  | otherwise    = (fromIntegral (pontosLinha l) / fromIntegral (jogos l * 3)) * 100.0

-- | Criterio composto de ordenacao da tabela:
-- 1. Maior numero de pontos
-- 2. Maior numero de vitorias
-- 3. Maior saldo de gols
-- 4. Maior numero de gols pro
-- 5. Ordem alfabetica do nome do time (desempate deterministico)
criterioClassificacao :: Linha -> Linha -> Ordering
criterioClassificacao =
  comparing (Down . pontosLinha)
    <> comparing (Down . vitorias)
    <> comparing (Down . saldo)
    <> comparing (Down . golsPro)
    <> comparing time

-- | Gera a tabela de classificacao ordenada a partir das partidas fornecidas.
classificacao :: [Partida] -> [Linha]
classificacao ps =
  sortBy criterioClassificacao . map (linhaDoTime ps) $ times ps

-- | Filtra apenas as partidas disputadas ate a rodada informada (inclusive).
ateRodada :: Int -> [Partida] -> [Partida]
ateRodada r = filter ((<= r) . rodada)

-- | Diferenca absoluta de gols em uma partida.
diferencaGols :: Partida -> Int
diferencaGols p = abs (golsMandante p - golsVisitante p)

-- | Retorna a partida com maior diferenca de gols, ou Nothing se a lista for vazia.
maiorGoleada :: [Partida] -> Maybe Partida
maiorGoleada [] = Nothing
maiorGoleada ps = Just (maximumBy (comparing diferencaGols) ps)

-- | Total de gols marcados em uma partida.
totalGolsPartida :: Partida -> Int
totalGolsPartida p = golsMandante p + golsVisitante p

-- | Calcula a media de gols por partida, ou Nothing se a lista for vazia.
mediaGols :: [Partida] -> Maybe Double
mediaGols [] = Nothing
mediaGols ps =
  let totalGols = sum (map totalGolsPartida ps)
  in Just (fromIntegral totalGols / fromIntegral (length ps))
