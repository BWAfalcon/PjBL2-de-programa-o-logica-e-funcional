module Main (main) where

import Classificacao
  ( aproveitamento
  , ateRodada
  , classificacao
  , linhaDoTime
  , maiorGoleada
  , mediaGols
  , pontos
  , pontosLinha
  , saldo
  )
import Dados
  ( dadosCampeonato
  , dadosCampeonatoComErros
  , dadosCampeonatoVazio
  )
import Leitura
  ( Erro (..)
  , lerCampeonato
  , lerPartida
  , separar
  , todosOsErros
  )
import Tipos
  ( Linha (..)
  , Partida (..)
  , Resultado (..)
  , participou
  , resultadoPara
  , times
  )

-- | Funcao auxiliar de assercao para tipos com Eq e Show.
testar :: (Eq a, Show a) => String -> a -> a -> IO ()
testar nome obtido esperado
  | obtido == esperado = putStrLn ("OK     - " ++ nome)
  | otherwise          = putStrLn ("FALHOU - " ++ nome ++ ": obtido " ++ show obtido ++ ", esperado " ++ show esperado)

-- | Funcao auxiliar de assercao com tolerancia para valores Double.
testarAprox :: String -> Double -> Double -> IO ()
testarAprox nome obtido esperado
  | abs (obtido - esperado) < 1e-6 = putStrLn ("OK     - " ++ nome)
  | otherwise                      = putStrLn ("FALHOU - " ++ nome ++ ": obtido " ++ show obtido ++ ", esperado " ++ show esperado)

main :: IO ()
main = do
  putStrLn "================ SUITE DE TESTES - PjBL2 ================"
  putStrLn ""

  -- -------------------------------------------------------------------------
  -- CAMADA 1: Tipos e consultas basicas
  -- -------------------------------------------------------------------------
  putStrLn "--- Camada 1: Tipos e Consultas Basicas ---"
  let pExemplo = Partida 1 "Coritiba" 2 1 "Athletico"
      pEmpate  = Partida 1 "Parana" 0 0 "Operario"

  testar "participou (mandante)" (participou "Coritiba" pExemplo) True
  testar "participou (visitante)" (participou "Athletico" pExemplo) True
  testar "participou (nao jogou)" (participou "Londrina" pExemplo) False

  testar "resultadoPara (mandante vence)" (resultadoPara "Coritiba" pExemplo) (Just Vitoria)
  testar "resultadoPara (visitante perde)" (resultadoPara "Athletico" pExemplo) (Just Derrota)
  testar "resultadoPara (empate 0x0)" (resultadoPara "Parana" pEmpate) (Just Empate)
  testar "resultadoPara (time ausente)" (resultadoPara "Maringa" pExemplo) Nothing

  let partidasValidas =
        case lerCampeonato dadosCampeonato of
          Right ps -> ps
          Left _   -> []

  testar
    "times (sem repeticao e em ordem alfabetica)"
    (times partidasValidas)
    ["Athletico", "Coritiba", "Londrina", "Maringa", "Operario", "Parana"]
  testar "times (lista vazia)" (times []) []
  putStrLn ""

  -- -------------------------------------------------------------------------
  -- CAMADA 2: Classificacao com funcoes de ordem superior
  -- -------------------------------------------------------------------------
  putStrLn "--- Camada 2: Classificacao e Estatisticas ---"
  testar "pontos Vitoria" (pontos Vitoria) 3
  testar "pontos Empate" (pontos Empate) 1
  testar "pontos Derrota" (pontos Derrota) 0

  let linhaAthletico = Linha "Athletico" 5 3 1 1 12 6
      linhaCoritiba  = Linha "Coritiba" 5 3 1 1 7 4
      linhaZerada    = Linha "Teste" 0 0 0 0 0 0

  testar "linhaDoTime (Athletico)" (linhaDoTime partidasValidas "Athletico") linhaAthletico
  testar "linhaDoTime (Coritiba)" (linhaDoTime partidasValidas "Coritiba") linhaCoritiba
  testar "pontosLinha (Athletico)" (pontosLinha linhaAthletico) 10
  testar "saldo (Athletico)" (saldo linhaAthletico) 6
  testar "saldo (Coritiba)" (saldo linhaCoritiba) 3
  testarAprox "aproveitamento (Athletico)" (aproveitamento linhaAthletico) (10.0 / 15.0 * 100.0)
  testarAprox "aproveitamento (time sem jogos)" (aproveitamento linhaZerada) 0.0

  let esperadoFinal =
        [ Linha "Athletico" 5 3 1 1 12 6
        , Linha "Coritiba"  5 3 1 1 7  4
        , Linha "Parana"    5 2 2 1 6  4
        , Linha "Londrina"  5 2 1 2 7  5
        , Linha "Maringa"   5 1 1 3 5  13
        , Linha "Operario"  5 0 2 3 4  9
        ]
  let tabelaFinal = classificacao partidasValidas
  testar "classificacao final completa (conferida a mao)" tabelaFinal esperadoFinal

  -- Desempate explicito por saldo de gols (ambos com 10 pontos e 3 vitorias)
  testar
    "desempate por saldo de gols entre Athletico (+6) e Coritiba (+3)"
    (map time (take 2 tabelaFinal))
    ["Athletico", "Coritiba"]

  -- Desempate sintetico por numero de vitorias (mesmos pontos: 6 pts)
  let partidasDesempateVitorias =
        [ Partida 1 "TimeA" 1 0 "TimeC"
        , Partida 2 "TimeA" 1 0 "TimeD"
        , Partida 1 "TimeB" 1 1 "TimeC"
        , Partida 2 "TimeB" 1 1 "TimeD"
        , Partida 3 "TimeB" 1 1 "TimeE"
        , Partida 4 "TimeB" 2 0 "TimeF"
        ]
  testar
    "desempate por vitorias (TimeB 2V vs TimeA 2V com saldo maior)"
    (take 2 (map time (classificacao partidasDesempateVitorias)))
    ["TimeA", "TimeB"]

  -- Classificacao apos 3a rodada diferente da classificacao final
  let tabelaRodada3 = classificacao (ateRodada 3 partidasValidas)
  testar
    "ateRodada 3: lider apos 3a rodada e Coritiba (7 pts)"
    (map time tabelaRodada3)
    ["Coritiba", "Londrina", "Athletico", "Parana", "Operario", "Maringa"]
  testar
    "classificacao apos 3a rodada difere da classificacao final"
    (tabelaRodada3 /= tabelaFinal)
    True

  testar
    "maiorGoleada no campeonato"
    (maiorGoleada partidasValidas)
    (Just (Partida 2 "Athletico" 4 0 "Maringa"))
  testar "maiorGoleada [] devolve Nothing" (maiorGoleada []) Nothing

  case mediaGols partidasValidas of
    Nothing -> putStrLn "FALHOU - mediaGols no campeonato: obtido Nothing"
    Just m  -> testarAprox "mediaGols no campeonato (41 / 15)" m (41.0 / 15.0)
  testar "mediaGols [] devolve Nothing" (mediaGols []) Nothing
  putStrLn ""

  -- -------------------------------------------------------------------------
  -- CAMADA 3: Leitura, validacao e tratamento de erros
  -- -------------------------------------------------------------------------
  putStrLn "--- Camada 3: Leitura e Validacao ---"
  testar "separar campos padrao" (separar ';' "1;Coritiba;2;1;Athletico") ["1", "Coritiba", "2", "1", "Athletico"]
  testar "separar campo vazio final" (separar ';' "1;Coritiba;2;1;") ["1", "Coritiba", "2", "1", ""]

  testar "lerCampeonato valido devolve Right com 15 partidas" (length partidasValidas) 15
  testar "lerCampeonato vazio devolve Right []" (lerCampeonato dadosCampeonatoVazio) (Right [])

  -- Um teste para cada construtor de Erro
  testar
    "Erro: CamposInvalidos"
    (lerPartida 10 "1; Coritiba; 2; 1")
    (Left (CamposInvalidos 10 "1; Coritiba; 2; 1"))

  testar
    "Erro: TimeVazio"
    (lerPartida 11 "1; ; 2; 1; Athletico")
    (Left (TimeVazio 11))

  testar
    "Erro: NumeroInvalido (placar 'dois')"
    (lerPartida 12 "1; Coritiba; dois; 1; Athletico")
    (Left (NumeroInvalido 12 "golsMandante" "dois"))

  testar
    "Erro: RodadaInvalida (rodada 0)"
    (lerPartida 13 "0; Coritiba; 2; 1; Athletico")
    (Left (RodadaInvalida 13 0))

  testar
    "Erro: PlacarNegativo"
    (lerPartida 14 "1; Coritiba; 2; -3; Athletico")
    (Left (PlacarNegativo 14 "golsVisitante" (-3)))

  testar
    "Erro: MesmoTime"
    (lerPartida 15 "1; Coritiba; 1; 1; Coritiba")
    (Left (MesmoTime 15 "Coritiba"))

  let textoTimeRepetido = unlines
        [ "1; Coritiba; 2; 0; Athletico"
        , "1; Parana; 1; 1; Coritiba"
        ]
  testar
    "Erro: TimeRepetidoNaRodada"
    (lerCampeonato textoTimeRepetido)
    (Left (TimeRepetidoNaRodada 2 1 "Coritiba"))

  testar
    "lerCampeonato com erros para no primeiro erro"
    (lerCampeonato dadosCampeonatoComErros)
    (Left (NumeroInvalido 3 "golsMandante" "dois"))

  let errosEsperados =
        [ NumeroInvalido 3 "golsMandante" "dois"
        , PlacarNegativo 5 "golsMandante" (-1)
        , MesmoTime 6 "Athletico"
        , CamposInvalidos 7 "3; Parana; 1; 0"
        , TimeRepetidoNaRodada 4 1 "Coritiba"
        ]
  testar
    "todosOsErros relata todos os erros do texto"
    (todosOsErros dadosCampeonatoComErros)
    errosEsperados

  putStrLn ""
  putStrLn "================ FIM DA EXECUCAO DOS TESTES ==============="
