# Decisões de Modelagem e Limitações Conhecidas

## 1. Arquitetura em Três Camadas

O projeto foi estruturado em módulos independentes que refletem a separação entre modelo de domínio, lógica pura de agregação/ordenação e fronteira de entrada/saída:

1. **Camada 1 (`src/Tipos.hs`)**: Define os tipos algébricos (`Resultado`, `Partida`, `Linha`), o sinônimo `Time` e as consultas elementares (`participou`, `resultadoPara`, `times`).
2. **Camada 2 (`src/Classificacao.hs`)**: Concentra exclusivamente transformações puras sobre listas usando funções de ordem superior (`map`, `filter`, `foldl`, `sortBy`, `maximumBy`), sem nenhuma recursão explícita.
3. **Camada 3 (`src/Leitura.hs`, `src/Dados.hs`, `src/Main.hs`)**: Isola o parsing textual, a validação via mônadas `Maybe` e `Either`, o relatório completo de erros e a formatação de saída, mantendo `Main.hs` restrito à orquestração de `IO`.

---

## 2. Principais Decisões de Modelagem

### 2.1 Tipos Algébricos e Records na Camada 1
- **`Partida` e `Linha` como *records***: Em vez de tuplas posicionais `(Int, String, Int, Int, String)`, o uso de campos nomeados (`golsMandante`, `golsVisitante`, `golsPro`, `golsContra`) impede a inversão acidental de valores do mesmo tipo (`Int`) e torna os seletores autoexplicativos.
- **`Resultado` como tipo soma fechado**: Modelar `Vitoria | Empate | Derrota` elimina estados inválidos (como strings arbitrarias `"v"` ou códigos numéricos fora de faixa) e permite ao compilador verificar exaustividade com `-Wall`.
- **`resultadoPara` retornando `Maybe Resultado`**: Torna explícito no sistema de tipos que um time pode não ter participado de determinada partida, evitando valores sentinela.

### 2.2 Uso de `foldl` e Composição de Critérios na Camada 2
- **`foldl` em `linhaDoTime`**: Optou-se por `foldl` sobre a lista filtrada de partidas do time (`filter (participou t) ps`) porque a construção da estatística acumulada (`jogos`, `vitorias`, `empates`, `derrotas`, `golsPro`, `golsContra`) parte de uma `linhaInicial` zerada e incorpora cada partida sequencialmente. Como cada time disputa poucas partidas por campeonato, `foldl` expressa diretamente o acúmulo cronológico das rodadas.
- **Ordenação multicritério via `Monoid` de `Ordering`**: Em vez de encadear múltiplas chamadas a `sortBy`, utilizou-se `comparing (Down . pontosLinha) <> comparing (Down . vitorias) <> comparing (Down . saldo) <> comparing (Down . golsPro) <> comparing time`. Como `Ordering` forma um `Monoid` em que `EQ <> x = x`, o primeiro critério diferente de empate decide a precedência de forma declarativa.
- **Escala de `aproveitamento` (0.0 a 100.0)**: Calculado como `(fromIntegral (pontosLinha l) / fromIntegral (jogos l * 3)) * 100.0`, seguindo o padrão adotado em tabelas de campeonatos brasileiros. Quando `jogos l == 0`, retorna `0.0` diretamente, evitando divisão por zero.
- **Totalidade em `maiorGoleada` e `mediaGols`**: Ambas tratam explicitamente o caso de lista vazia (`[] -> Nothing`), evitando funções parciais como `head` ou `maximum` sobre listas potencialmente vazias.

### 2.3 Validação Total com `Maybe` e `Either` na Camada 3
- **Preservação do número original da linha**: `linhasRelevantes` realiza `zip ([1 ..] :: [Int]) . lines` *antes* de filtrar comentários (`#`) e linhas em branco. Dessa forma, qualquer erro apontado ao usuário indica exatamente a linha real do arquivo de entrada.
- **Notação `do` em `Either Erro` e `traverse`**: Em `lerPartida`, cada etapa de validação (quantidade de campos, nome não vazio, parsing numérico com `readMaybe`, rodada positiva, placar não negativo e times distintos) é encadeada na mônada `Either Erro`, interrompendo no primeiro problema sem lançar exceções em tempo de execução. Em `lerCampeonato`, `traverse (uncurry lerPartida)` aplica essa validação a todas as linhas e propaga o primeiro `Left`.
- **Relatório completo em `todosOsErros`**: Complementando `lerCampeonato`, `todosOsErros` separa os erros de parsing (`lefts`) das partidas válidas (`rights`) e executa uma varredura de duplicidade por rodada para listar todas as inconsistências de uma só vez.
- **Dados embutidos em `Dados.hs`**: Para garantir compatibilidade tanto com o GHC local quanto com ambientes online sem `stdin` (`play.haskell.org`), os cenários de entrada são definidos como `String` em `Dados.hs`, sem chamadas bloqueantes a `getLine`.

---

## 3. Limitações Conhecidas

1. **Critérios de desempate avançados**: A ordenação contempla pontos, vitórias, saldo de gols, gols pró e ordem alfabética como desempate determinístico final. Critérios regulamentares adicionais, como confronto direto, número de cartões vermelhos/amarelos ou sorteio, não foram modelados.
2. **Completude da tabela de jogos**: O sistema valida que nenhum time joga mais de uma vez na mesma rodada (`TimeRepetidoNaRodada`), mas não exige que todas as rodadas tenham o mesmo número de partidas nem que o campeonato forme um turno único completo (todos contra todos), permitindo consultar classificações parciais ou em andamento.
3. **Nomes de times com variações ortográficas**: A comparação de duplicidade na rodada e de confronto contra si mesmo normaliza caixa (`toLower`) e espaços externos (`aparar`), mas variações de acentuação ou abreviações (ex.: `"Athletico"` vs `"Athletico-PR"`) são tratadas como equipes distintas.
4. **Leitura de arquivos externos**: Por portabilidade com o playground online, `Main.hs` lê as strings definidas em `Dados.hs`. Em uma evolução para CLI local, `lerCampeonato` pode ser facilmente conectado a `readFile` sem alterar nenhuma função das Camadas 1, 2 ou 3.
